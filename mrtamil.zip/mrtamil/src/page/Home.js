import React from "react";

const Home = () => {
  return (
    
    <React.StrictMode>
  <div id="carouselExampleFade" className="carousel slide carousel-fade" data-bs-ride="carousel">
    <div className="carousel-inner">
        <div className="carousel-item active">
            <img src="assets/images/slider/n1.jpg" className="d-block w-100" alt="..." />
        </div>
        <div className="carousel-item">
            <img src="assets/images/slider/n2.jpg" className="d-block w-100" alt="..." />
        </div>
        <div className="carousel-item">
            <img src="assets/images/slider/n3.jpg" className="d-block w-100" alt="..." />
        </div>
        <div className="carousel-item">
            <img src="assets/images/slider/s1.jpg" className="d-block w-100" alt="..." />
        </div>
        <div className="carousel-item">
            <img src="assets/images/slider/s2.jpg" className="d-block w-100" alt="..." />
        </div>
        <div className="carousel-item">
            <img src="assets/images/slider/s3.jpg" className="d-block w-100" alt="..." />
        </div>
    </div>
    <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
        <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Previous</span>
    </button>
    <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
        <span className="carousel-control-next-icon" aria-hidden="true"></span>
        <span className="visually-hidden">Next</span>
    </button>
</div>


        <div className="services container-fluid big-padding">
            <div className="container-lg">
                <div className="section-title row">
                    <h2>Our Services</h2>
                    
                </div>
                <div className="row">
                    <div className="col-md-4 border-end border-md-0 border-bottom">
                        <div className="service text-center p-4">
                            <i className="bi fs-11 bi-camera"></i>
                            <h2 className="fs-5 mb-4 fw-bold">Wedding Photography</h2>
                            <p className="fs-7">Quisque lacinia sem sit amet odio finibus, ac sollicitudin elit finibus. Morbi nulla metus, vulputate sed commodo at, tincidunt in ante. Phasellus commodo turpis lorem, a tincidunt arcu imperdiet ac.</p>
                        </div>
                    </div>
                    <div className="col-md-4 border-end border-md-0 border-bottom">
                        <div className="service text-center p-4">
                            <i className="bi fs-11 bi-camera2"></i>
                            <h2 className="fs-5 mb-4 fw-bold">Candid Photography</h2>
                            <p className="fs-7">Quisque lacinia sem sit amet odio finibus, ac sollicitudin elit finibus. Morbi nulla metus, vulputate sed commodo at, tincidunt in ante. Phasellus commodo turpis lorem, a tincidunt arcu imperdiet ac.</p>
                        </div>
                    </div>
                    <div className="col-md-4 border-md-0 border-bottom">
                        <div className="service text-center p-4">
                            <i className="bi fs-11 bi-camera-reels"></i>
                            <h2 className="fs-5 mb-4 fw-bold">Videography</h2>
                            <p className="fs-7">Quisque lacinia sem sit amet odio finibus, ac sollicitudin elit finibus. Morbi nulla metus, vulputate sed commodo at, tincidunt in ante. Phasellus commodo turpis lorem, a tincidunt arcu imperdiet ac.</p>
                        </div>
                    </div>
                    <div className="col-md-4 border-md-0 border-end">
                        <div className="service text-center p-4">
                            <i className="bi fs-11 bi-journal-album"></i>
                            <h2 className="fs-5 mb-4 fw-bold">Album Design</h2>
                            <p className="fs-7">Quisque lacinia sem sit amet odio finibus, ac sollicitudin elit finibus. Morbi nulla metus, vulputate sed commodo at, tincidunt in ante. Phasellus commodo turpis lorem, a tincidunt arcu imperdiet ac.</p>
                        </div>
                    </div>
                    <div className="col-md-4 border-md-0 border-end">
                        <div className="service text-center p-4">
                            <i className="bi fs-11 bi-images"></i>
                            <h2 className="fs-5 mb-4 fw-bold">Photo Restoration</h2>
                            <p className="fs-7">Quisque lacinia sem sit amet odio finibus, ac sollicitudin elit finibus. Morbi nulla metus, vulputate sed commodo at, tincidunt in ante. Phasellus commodo turpis lorem, a tincidunt arcu imperdiet ac.</p>
                        </div>
                    </div>
                    <div className="col-md-4 ">
                        <div className="service text-center p-4">
                            <i className="bi fs-11 bi-film"></i>
                            <h2 className="fs-5 mb-4 fw-bold">Video Editing</h2>
                            <p className="fs-7">Quisque lacinia sem sit amet odio finibus, ac sollicitudin elit finibus. Morbi nulla metus, vulputate sed commodo at, tincidunt in ante. Phasellus commodo turpis lorem, a tincidunt arcu imperdiet ac.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="services container-fluid big-padding bg-gray">
                <div class="container-lg">
                    <div class="section-title row">
                        <h2 class="fw-bolder">Our Albums</h2>
                       
                    </div>
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <div class="album-cover rounded p-2 bg-white shadow-md">
                                <img class="p-1" src="assets/images/album/a1.jpg" alt=""/>
                                <h4 class="mt-3 fw-bolder fs-6">Jasom vs Emily</h4>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="album-cover rounded p-2 bg-white shadow-md">
                                <img class="p-1" src="assets/images/album/a4.jpg" alt=""/>
                                <h4 class="mt-3 fw-bolder fs-6">Jasom vs Emily</h4>
                            </div>
                        </div>
                        <div class="col-md-4 text-center">
                            <div class="album-cover rounded p-2 bg-white shadow-md">
                                <img class="p-1" src="assets/images/album/a5.jpg" alt=""/>
                                <h4 class="mt-3 fw-bolder fs-6">Jasom vs Emily</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            
            {/* <div style={{ marginBottom: "50px" }} className="container">
      <div style={{ marginTop: "10px" }} className="services">
        <div className="row title center">
          <h2>What We Do ?</h2>
          <b>We offer a wide range of services to choose</b>
        </div>

        <div className="row">
          <ServiceItem icon={faUser} title="Candid Photography" description="It is all about capturing moments as it is and surprising the subject. Our photographers are trained to capture every essence" />
          <ServiceItem icon={faFilm} title="Cinematic Videography" description="We adopt cinematic techniques and creative storytelling to ensure your viewing experience is highly fun, filled with pleasure" />
          <ServiceItem icon={faPhoto} title="Digital Album" description="Our creative designers make your photos attractive and storytelling. The final output as a printed album will be made to capture every essence" />
          <ServiceItem icon={faVideoCamera} title="Event Videography" description="As event photography, we give the same attention to detail and thoroughness for event videography as well." />
          <ServiceItem icon={faPlayCircle} title="Live Webcast" description="Be it a wedding, a corporate presentation, or any event, webcasting is made simple by us. Viewers can" />
          <ServiceItem icon={faTags} title="Product Shoot" description="We do follow the most important product photography rules such as using a tripod, wide aperture, white background, etc." />
        </div>
      </div>
    </div> */}

   
<div class="services container-fluid big-padding bg-gray">
    <div class="container-lg">
        <div class="section-title row">
            <h2 class="fw-bolder">Our Albums</h2>
        </div>
        <div className="container">
            <div className="row">
                <div className="col-sm-6">
                    <iframe title="Album 1" style={{ width: '100%' }} height="315" src="https://www.youtube.com/embed/IYqarbJN2Sk?si=T_LQ_gvYPfLtU3XT" frameborder="0" allowfullscreen></iframe>
                </div>
                <div className="col-sm-6">
                    <iframe title="Album 2" style={{ width: '100%' }} height="315" src="https://www.youtube.com/embed/4valZtm-Kk8?si=miqr8iC4vxpI2A8j" frameborder="0" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </div>
</div>




{/* contact */}
      <div className="row contact-rooo big-padding no-margin">
        <div className="container">
          <div className="row">
            <div style={{ padding: '20px' }} className="col-sm-7">
              <h2 className="fs-4 fw-bold">Contact Form</h2> <br />
              <div className="row cont-row">
                <div className="col-sm-3"><label>Enter Name </label><span>:</span></div>
                <div className="col-sm-8"><input type="text" placeholder="Enter Name" name="name" className="form-control input-sm" /></div>
              </div>
              <div className="row cont-row">
                <div className="col-sm-3"><label>Email Address </label><span>:</span></div>
                <div className="col-sm-8"><input type="text" name="name" placeholder="Enter Email Address" className="form-control input-sm" /></div>
              </div>
              <div className="row cont-row">
                <div className="col-sm-3"><label>Mobile Number</label><span>:</span></div>
                <div className="col-sm-8"><input type="text" name="name" placeholder="Enter Mobile Number" className="form-control input-sm" /></div>
              </div>
              <div className="row cont-row">
                <div className="col-sm-3"><label>Enter Message</label><span>:</span></div>
                <div className="col-sm-8">
                  <textarea rows="5" placeholder="Enter Your Message" className="form-control input-sm"></textarea>
                </div>
              </div>
              <div style={{ marginTop: '10px' }} className="row">
                <div style={{ paddingTop: '10px' }} className="col-sm-3"><label></label></div>
                <div className="col-sm-8">
                  <button className="btn btn-danger fs-5 btn-sm">Send Message</button>
                </div>
              </div>
            </div>
            <div className="col-sm-5">
              <div style={{ margin: '50px' }} className="serv">
                <h2 className="fs-4 fw-bold" style={{ marginTop: '10px' }}>Address</h2>
                <p className="fs-5">
                  Mr.Tamil Photography <br />
                  mariyamman kovil Street,chokkanathanputhur<br />
                  Virudhunagar District<br />
                  Phone:+91 9360343393<br />
                  Email:mr.tamilrjpm@gmail.com<br />

                  <iframe
    style={{ width: '150%', border: '0' }}
    src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d249759.19784092825!2d79.10145254589841!3d12.009924873581818!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1448883859107"
    height="200"
    allowFullScreen
    title="Google Maps"
  ></iframe>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
  

     
    </React.StrictMode>
  );
};

export default Home;
