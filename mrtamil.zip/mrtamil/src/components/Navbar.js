import React from "react";
import { Link } from 'react-router-dom';


function Navbar() {
  return (
    <React.StrictMode>
       <header>
            <div className="hed-top bg-danger d-none d-sm-block">
                <div className="container-lg">
                    <div className="row">
                        <div className="col-lg-6 d-none d-lg-block">
                            <ul className="text-light fw-bold fs-8">
                                <li className="float-start p-3"><i className="bi bi-envelope"></i> mr.tamilrjpm@gmail.com</li>
                                <li className="float-start p-3"><i className="bi bi-telephone"></i> +91 93 60 34 33 93</li>
                            </ul>
                        </div>
                        <div className="col-lg-6">
                            <ul className="text-light float-end">
                                <li className="float-start p-3"><i className="bi bi-facebook"></i></li>
                                <li className="float-start p-3"><i className="bi bi-twitter"></i></li>
                                <li className="float-start p-3"><i className="bi bi-instagram"></i></li>
                                <li className="float-start p-3"><i className="bi bi-linkedin"></i></li>
                                <li className="float-start pt-2 ms-4">
                                    <button className="btn fs-8 fw-bold btn-light">Login / Sign Up</button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div id="menu-jk" className="nav-part">
                <div className="container-lg">
                    <div className="row shadow bg-white navcol p-2">
                        <div className="col-lg-4">
                            <img className="max-230" src="assets/images/logo.png" alt="" />
                        </div>
                        <div id="menu" className="col-lg-8 d-none d-lg-block">
                            <ul className="fw-bold float-end nacul fs-7">
                                <li className="float-start p-3 px-4"><Link to="/">Home</Link></li>
                                <li className="float-start p-3 px-4"><Link to="/page/About.js">About Us</Link></li>
                                <li className="float-start p-3 px-4"><Link to="/page/Services.js">Services</Link></li>
                                <li className="float-start p-3 px-4"><Link to="/page/ontact.js">Contact Us</Link></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    </React.StrictMode>
  );
}

export default Navbar;
