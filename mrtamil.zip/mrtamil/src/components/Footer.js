import React from 'react';

function Footer() {
  return (
    <></>
//     <div className="footer container-fluid" style={{ backgroundColor: '#333', color: '#fff' }}>
//     <div className="container">
//         <div style={{ padding: '20px' }} className="row fot-data">
//             <div className="col-sm-4">
//                 <b>Shortly About Us</b>
//                 <p>Hills Modeling Studio has a team of professionals with a strong desire to document real life through photography. Having a creative eye, we offer our photography service for fashion, portfolios, products, weddings, events, web designing, catalog designing, and print media.</p>
//             </div>
//             <div className="col-sm-2">
//                 <b>Contact Us</b>
//                 <ul className="foot-list">
//                     <li><i className="fa fa-phone"></i> (+91)9360343393</li>
//                     <li><i style={{ fontSize: '9px' }} className="fa fa-envelope"></i> mr.tamilrjpm@gmail.com</li>
//                     <li><i className="fa fa-skype"></i> isulastudioads</li>
//                 </ul>
//             </div>
//             <div className="col-sm-2">
//                 <ul className="foot-list">
//                     <li><i className="fa fa-map-marker"></i> No:37, Mariamman Street,</li>
//                     <li style={{ marginLeft: '30px' }}>chokkanathanputhur</li>
//                     <li style={{ marginLeft: '30px' }}>Virudhunagar District</li>
//                 </ul>
//             </div>
//             <div className="col-sm-4">
//                 <b>Working Hours</b>
//                 <ul className="workday">
//                     <li>Monday - <span style={{ float: 'right' }}>8.30 AM - 7.30 PM</span></li>
//                     <li>Tuesday - <span style={{ float: 'right' }}>8.30 AM - 7.30 PM</span></li>
//                     <li>Wednesday - <span style={{ float: 'right' }}>8.30 AM - 7.30 PM</span></li>
//                     <li>Thursday - <span style={{ float: 'right' }}>8.30 AM - 7.30 PM</span></li>
//                     <li>Friday - <span style={{ float: 'right' }}>8.30 AM - 7.30 PM</span></li>
//                     <li>Saturday - <span style={{ float: 'right' }}>8.30 AM - 7.30 PM</span></li>
//                 </ul>
//             </div>
//         </div>
//     </div>
//     <div className="container-fluid foot-bot" style={{ backgroundColor: '#222' }}>
//         <div style={{ padding: '15px', color: '#c12e2a', paddingBottom: '0px' }} className="container">
//             {/* Provide a valid href value for the anchor */}
//             <a href="https://www.example.com">2024 &copy; All Rights Reserved | Designed andDeveloped by PSM and GK</a>
//             <ul style={{ marginTop: '-20px' }} className="sh-rt">
//                 <li> <i className="fa fa-facebook"></i> </li>
//                 <li> <i className="fa fa-twitter"></i></li>
//                 <li> <i className="fa fa-pinterest-p"></i> </li>
//                 <li> <i className="fa fa-tumblr"></i> </li>
//                 <li> <i className="fa fa-google-plus"></i> </li>
//                 <li> <i className="fa fa-youtube"></i> </li>
//             </ul>
//         </div>
//     </div>
// </div>

  );
}

export default Footer;
